/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clase;

/**
 *
 * @author gaby
 */
public interface IOperatiiCurs {
    public void UpdateProfesor(Profesor p);    
    public void AddStudent(Student student);
    public void RemoveStudent(Student student);
    public void UpdateStudent(Student student);
    public void UpdateCurs(String nume, String descriere);
}
