package clase;

import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;

public class TXTManager implements ISourceManager {
    private List<Curs> cursuri;
    FileWriter fwriter;
    FileReader freader;

    public TXTManager() throws IOException {
        fwriter = new FileWriter("db.txt");
        QueryCursuri();
    }

    @Override
    public Collection<Curs> getCursuri() {
        return this.cursuri;
    }

    @Override
    public void setCursuri(Collection<Curs> cursuri) {

    }

    @Override
    public void AddCurs(Curs curs) throws IOException {
        this.cursuri.add(curs);
        try {
            fwriter =  new FileWriter("db.txt");
            String str="";
            for(Curs c : cursuri)
                str+=c + "\n";
            fwriter.write(str);
            fwriter.flush();
        }
        catch (Exception ex)
        {
            System.out.println(ex);
        }
        finally {
            fwriter.close();
        }

    }

    @Override
    public void UpdateCurs(Curs curs) {

    }

    @Override
    public void DeleteCurs(Curs curs) {

    }

    @Override
    public List<Curs> QueryCursuri() {

        //cum preiau din fisier?

        cursuri = new ArrayList<Curs>();
        //definire studenti
        HashSet<Student> studenti = new HashSet<Student>();
        studenti.add(new Student("Andrei","Negoita",2231));
        studenti.add(new Student("Ion","Mateescu",4221));


        //definire profesor
        Profesor prof = new Profesor("Anton","Panaitescu");
        //definire curs nou
        cursuri.add( new Curs("Rezistenta Materialelor", "calculul reacţiunilor,\n" +
                "diagramele de eforturi, calculul caracteristicilor geometrice ale\n" +
                "suprafeţelor plane şi calculul elementelor de rezistenţă la solicitări simple\n"
                , prof, studenti));
        return cursuri;
    }
}
