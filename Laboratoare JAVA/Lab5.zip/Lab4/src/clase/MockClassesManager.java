/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clase;

import java.util.*;

/**
 *
 * @author gaby
 */
public class MockClassesManager implements ISourceManager{


    private Set<Curs> cursuri ;

    public MockClassesManager()
    {
        QueryCursuri();
    }

    @Override
    public void AddCurs(Curs curs) {
       cursuri.add(curs);
    }

    @Override
    public void UpdateCurs(Curs curs) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void DeleteCurs(Curs curs) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public Collection<Curs> QueryCursuri() {
        cursuri = new HashSet<>();
        //definire studenti
        Student[] studenti_array = new Student[]{
                new Student("Andrei","Negoita",2231),
                new Student("Andrei","Negoita",2232),
                new Student("Ion","Mateescu",4221)
        };
        Set<Student> studentilocal = new HashSet<Student>(Arrays.asList(studenti_array));


        //definire profesor
        Profesor prof = new Profesor("Anton","Panaitescu");
        //definire curs nou
        cursuri.add( new Curs("Rezistenta Materialelor1", "Desc1", prof, studentilocal));
        cursuri.add( new Curs("Rezistenta Materialelor2", "Desc2", prof, studentilocal));
        cursuri.add( new Curs("Rezistenta Materialelor3", "Desc3", prof, studentilocal));

        return cursuri;
    }


    @Override
    public Collection<Curs> getCursuri() {
        return this.cursuri;
    }

    @Override
    public void setCursuri(Collection<Curs> cursuri) {
        //if validations are ok on cursuri |^
        this.cursuri = (HashSet<Curs>)cursuri;
    }
}
