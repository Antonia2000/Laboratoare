/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clase;

/**
 *
 * @author gaby
 */
public class Profesor extends Persoana{  

    @Override
    public String toString() {
        return "Profesor{" + "nume=" + nume + ", prenume=" + prenume + '}';
    }
    
    public Profesor(String nume, String prenume)
    {
        this.nume = nume;
        this.prenume = prenume;
    }
}
