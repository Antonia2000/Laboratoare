/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clase;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

/**
 *
 * @author gaby
 */
public class Curs implements IOperatiiCurs{
    String nume;
    String descriere;
    Profesor profu;
    Set<Student> studenti;
    
    @Override
    public void RemoveStudent(Student student) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void UpdateStudent(Student student) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void UpdateCurs(String nume, String descriere) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
   
    public Curs()
    {
        this.nume = "";
        this.descriere = "";
        this.profu = null;
        this.studenti = new HashSet<Student>();
    }
    public Curs(String nume, String descriere, Profesor profu, Set<Student> studenti)
    {
        this.nume = nume;
        this.descriere = descriere;
        this.profu = profu;
        this.studenti = studenti;
    }
    public void UpdateProfesor(Profesor profu)
    {
        this.profu = profu;
    }
    public void AddStudent(Student student)
    {
        this.studenti.add(student);
    }

    @Override
    public String toString() {
        String str = 
                "Curs: " + "nume=" + nume + ", descriere=" + descriere + ",\nprofu=" + profu + ",\nstudenti:\n" ;
        for(Student s : studenti)
        {
            str+= s + "\n";
        }
        return str;
    }
    
    
}
