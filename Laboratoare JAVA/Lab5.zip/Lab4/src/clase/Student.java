/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clase;

/**
 *
 * @author gaby
 */
public class Student extends Persoana{   
    int grupa;

    @Override
    public int hashCode() {
       return nume.hashCode() * 17 + prenume.hashCode()*31; //to be added grupa
    }

    @Override
    public boolean equals(Object obj) {
      Student s = (Student)obj;
      //s compare to this
      return this.nume.compareTo(s.nume)==0 && this.prenume.compareTo(s.prenume)==0; //to be added grupa
    }

    public Student(String nume, String prenume, int grupa)
    {
        this.nume = nume;
        this.prenume = prenume;
        this.grupa = grupa;
    }

    @Override
    public String toString() {
        return "Student{" + "nume=" + nume + ", prenume=" + prenume + ", grupa=" + grupa + '}';
    }
    
    public String getNume() {
        return nume;
    }

    public void setNume(String nume) {
        this.nume = nume;
    }

    public String getPrenume() {
        return prenume;
    }

    public void setPrenume(String prenume) {
        this.prenume = prenume;
    }

    public int getGrupa() {
        return grupa;
    }

    public void setGrupa(int grupa) {
        this.grupa = grupa;
    }
    
    
}
