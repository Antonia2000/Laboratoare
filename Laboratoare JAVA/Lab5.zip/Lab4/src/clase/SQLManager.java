/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clase;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Collection;
import java.util.List;

/**
 *
 * @author gaby
 */
public class SQLManager implements ISourceManager {
    
    static final String DB_URL = "jdbc:sqlserver://danciugabyserver.database.windows.net:1433;"
            + "database=DBFiles;user=gaby@danciugabyserver;password=Parola12;"
            + "encrypt=true;trustServerCertificate=false;hostNameInCertificate=*.database.windows.net;"
            + "loginTimeout=30;";

    @Override
    public void AddCurs(Curs curs) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void UpdateCurs(Curs curs) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void DeleteCurs(Curs curs) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public Collection<Curs> QueryCursuri() {
        return null;
    }

    public Curs[] GetCursuri() {
        Connection conn = null;
        Curs[] cursuri = new Curs[0];
        try {
            System.out.println("Connecting to a selected database...");

            conn = DriverManager.getConnection(DB_URL);
            System.out.println("Connected database successfully...");
            System.out.println("Getting the data...");

            Statement stmt = null;
            System.out.println("Creating statement...");
            stmt = conn.createStatement();

            String sql = "USE [DBFiles];\n"
                    + "\n"
                    + "SELECT Course.id,\n"
                    + "      [name],\n"
                    + "      [description],\n"
                    + "      [ProfesorID],\n"
                    + "	  Profesor.id , first_name, last_name\n"
                    + "  FROM [dbo].[Course]\n"
                    + "  INNER JOIN dbo.Profesor \n"
                    + "  ON Profesor.id = Course.id";

            ResultSet rs = stmt.executeQuery(sql);
            //STEP 5: Extract data from result set            
            int index = 0;
            while (rs.next()) {
                //Retrieve by column name
                Curs c = new Curs();
                c.nume = rs.getString("name");
                c.descriere = rs.getString("description");
                Profesor profu = new Profesor(rs.getString("first_name"),
                        rs.getString("last_name"));
                c.profu = profu;
                System.out.println(c);
            }
            rs.close();

            System.out.println("Data retrieved.");
        } catch (SQLException se) {
            //Handle errors for JDBC
            se.printStackTrace();
        } catch (Exception e) {
            //Handle errors for Class.forName
            e.printStackTrace();
        } finally {
            //finally block used to close resources
            try {
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException se) {
                se.printStackTrace();
            }//end finally try
        }//end try
        return cursuri;
    }

    @Override
    public Collection<Curs> getCursuri() {
        return null;
    }

    @Override
    public void setCursuri(Collection<Curs> cursuri) {

    }
}
