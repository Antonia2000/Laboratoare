/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clase;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;

/**
 *
 * @author gaby
 */
public class ManagerCursuri {


    ISourceManager smanager ;

   
    public ManagerCursuri(Sources source) throws IOException {
      switch (source)
      {
          case SQLDataBase:
              smanager = new SQLManager();
              break;
          case MySQLDataBase:
              smanager = new MySQLManager();
              break;
          case XMLFile:
               smanager = new XMLManager();
              break;
          case TXTFile:File:
              smanager = new TXTManager();
              break;
          case MockData:
          default: 
              smanager = new MockClassesManager();
      }

    }



    public void AfiseazaCursuriLaConsola() {
        for (Curs c : smanager.getCursuri()) {
            System.out.println(c);
        }
    }
}
