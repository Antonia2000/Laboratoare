/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clase;


import java.util.Collection;
import java.util.List;

/**
 *
 * @author gaby
 */
public class XMLManager implements ISourceManager{

    @Override
    public void AddCurs(Curs curs) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void UpdateCurs(Curs curs) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void DeleteCurs(Curs curs) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public Collection<Curs> QueryCursuri() {
        return null;
    }


    @Override
    public Collection<Curs> getCursuri() {
        return null;
    }

    @Override
    public void setCursuri(Collection<Curs> cursuri) {

    }
}
