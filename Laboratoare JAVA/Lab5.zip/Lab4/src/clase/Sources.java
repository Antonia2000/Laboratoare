/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clase;

/**
 *
 * @author gaby
 */
public enum Sources {
    SQLDataBase, MySQLDataBase, XMLFile, MockData, TXTFile
}
