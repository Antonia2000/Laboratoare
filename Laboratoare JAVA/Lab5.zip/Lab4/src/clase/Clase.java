/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clase;

import java.util.HashSet;

/**
 *
 * @author gaby
 */
public class Clase {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        try {
            //adaugare curs in lista de cursuri
            clase.ManagerCursuri managercursuri = new clase.ManagerCursuri(Sources.MockData);
            Curs curs = new Curs();
            managercursuri.smanager.AddCurs(curs);
            managercursuri.AfiseazaCursuriLaConsola();
        }
        catch(Exception e)
        {
            System.out.println(e);
        }
    }
    
}
