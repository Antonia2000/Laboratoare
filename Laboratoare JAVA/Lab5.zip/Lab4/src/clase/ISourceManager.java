/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clase;

import java.util.Collection;
import java.util.List;

/**
 *
 * @author gaby
 */
public interface ISourceManager extends IOperatiiManagerCursuri{


     public Collection<Curs> getCursuri() ;

     public void setCursuri(Collection<Curs> cursuri) ;
     
}
